<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title><?php echo $this->lang->line('label_text_banner_content');?></title>
</head>
<body>
<div style="min-height:150px;min-width:300px;border: 1px solid #c7c7c7;margin:15px;padding:10px;max-width:600px;" >
<?php
echo $textbanner;
?>
</div>
</body>
</html>
