<h1>PayPal Library for Code Igniter</h1>

<?=$paypal_form?>