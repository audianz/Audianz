<div class="form_default" align="center">
    <fieldset>
    <br/>
    <img src="<?php echo base_url(); ?>assets/images/payment_success.png" />
    <br/>
    <h1 class="pageTitle"><?php echo $this->lang->line('lang_admin_pay_has_success_paid_and_verified');?></h1>
    <p><a href="<?php echo site_url('admin/approvals/payments'); ?>"><?php echo $this->lang->line('lang_admin_click_here');?></a><?php echo $this->lang->line('lang_admin_pay_more_for_other_pub');?></p>
    </fieldset>
</div>
