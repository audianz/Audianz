package com.example.Nameofyouractivity;

import com.example.Nameofyouractivity.adsdk.MjaXAdmanager;

import android.os.Bundle;
import android.app.Activity;
public class Nameofyouractivity extends Activity {
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.mjaxlayout);
	        MjaXAdmanager widget = (MjaXAdmanager)findViewById(R.id.mjaxlayoutid);
	        widget.setServer("Our Delivery Engine URL");//Get from your Dashboard
	        widget.setZoneId(1234567890); //Get from your Dashboard
	    }
	}
