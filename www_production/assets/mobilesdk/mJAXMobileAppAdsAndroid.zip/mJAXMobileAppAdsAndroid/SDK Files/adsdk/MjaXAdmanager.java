package com.example.Nameofyouractivity.adsdk;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookieStore;
import java.net.HttpCookie;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.provider.Browser;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import java.lang.String;
@SuppressWarnings("unused")
@SuppressLint("NewApi")
public class MjaXAdmanager extends ImageView {
private static final String LOG_PREFIX = "MjaXAdmanager";
private static final String AD_FETCH_SCRIPT = "avw.php?";
private static final String CALLBACK_SCRIPT = "ck.php?";
private final MyUpdater UPDATER = new MyUpdater();
private String serverPrefix;
private String zoneId;
private String openXParameters;
private Thread updaterThread;
private Handler handler = new Handler();
public MjaXAdmanager(final Context context) {
		super(context);
		setupAd(context);		
	}
	public MjaXAdmanager(final Context context, final AttributeSet attributes) {
		super(context,attributes);		
		setupAd(context);
	}	
	public void setupAd(final Context context) {
		super.setOnClickListener(new OnClickListener() {
			public void onClick(final View v) {
				if( openXParameters == null)
					return;
				final StringBuilder callbackURL = new StringBuilder(128);
				callbackURL.append(serverPrefix);
				callbackURL.append(CALLBACK_SCRIPT);
				callbackURL.append(openXParameters);
				callbackURL.append("&bannerid=");						
				SharedPreferences  mJAXspload = PreferenceManager.getDefaultSharedPreferences(getContext());
	            String cookienameandvalue = mJAXspload.getString("OAID", null);	
	            String cookienameandvaluearrayid= mJAXspload.getString("newCallbackId", null);
	            String cookienameandvaluearray= mJAXspload.getString("OAVARS[ad"+cookienameandvaluearrayid+"]", null);	
				System.out.println("OAID="+cookienameandvalue);					
				String str = cookienameandvaluearray;				
				callbackURL.append(str.substring(nthOccurrence(str, "%22", 2)+3,nthOccurrence(str, "%22", 3)));
				System.out.println("OAVARS[ad"+cookienameandvaluearrayid+"]="+cookienameandvaluearray);
	            final Intent adPassthrough = new Intent(Intent.ACTION_VIEW);
				adPassthrough.setData(Uri.parse(callbackURL.toString()));
			     Bundle bundle = new Bundle();
		         bundle.putString("Cookie","OAVARS[ad"+cookienameandvaluearrayid+"]="+cookienameandvaluearray);		         
		         adPassthrough.putExtra(Browser.EXTRA_HEADERS, bundle);
				context.startActivity(adPassthrough);				
			}		
		});		
		Timer timer = new Timer(); 
		timer.scheduleAtFixedRate(new TimerTask() 
		    { 
			public void run() {
				startAdUpdate();					
			}			
		    },0,90000);		
	}	
	public int nthOccurrence(String str, String string, int n) {
	    int pos = str.indexOf(string, 0);
	    while (n-- > 0 && pos != -1)
	    pos = str.indexOf(string, pos+1);
	    return pos;
	}	
	public String getZoneId() {
		return zoneId;
	}
	public void setZoneId(final String zoneId) {
		this.zoneId = zoneId;
	}
	public void setZoneId(final int zoneId) {
		setZoneId(Integer.toString(zoneId));
	}
	public void setServer(final String serverName) {
		final StringBuilder baseURLBuilder = new StringBuilder(serverName.length()+8);
		baseURLBuilder.append("http://");
		baseURLBuilder.append(serverName);
		baseURLBuilder.append('/');
		serverPrefix = baseURLBuilder.toString();
	}
	public synchronized void startAdUpdate() {
		if( zoneId == null ) {
			return;
		}		
		if(updaterThread != null && updaterThread.isAlive()) {
			return;
		}		
		try {
			updaterThread = new Thread(UPDATER);
			updaterThread.start();
		} catch (Exception ex) {
			Log.e(MjaXAdmanager.LOG_PREFIX, "Exception starting ad update", ex);
		}
	}
	@SuppressLint("NewApi")
	private class MyUpdater implements Runnable {
		@TargetApi(Build.VERSION_CODES.GINGERBREAD)
		@SuppressLint("NewApi")
		public void run() {
			String newCallbackId = Long.toString(System.currentTimeMillis(),16);
			if(newCallbackId.length() > 6) {
				newCallbackId = newCallbackId.substring(newCallbackId.length()-6);
			}			
			final StringBuilder callbackParametersBuilder = new StringBuilder(128);
			callbackParametersBuilder.append("zoneid=");
			callbackParametersBuilder.append(zoneId);
			callbackParametersBuilder.append("&cb=");
			callbackParametersBuilder.append(newCallbackId);
			callbackParametersBuilder.append("&n=ad");
			callbackParametersBuilder.append(newCallbackId);
			SharedPreferences mJAXspstore = PreferenceManager.getDefaultSharedPreferences(getContext());
			SharedPreferences.Editor editor = mJAXspstore.edit(); 
			editor.putString("newCallbackId", newCallbackId);    
			editor.commit();			
			final String newOpenXParameters = callbackParametersBuilder.toString();
			StringBuilder adURLBuilder = new StringBuilder(128);	
			adURLBuilder.append(serverPrefix);
			adURLBuilder.append(AD_FETCH_SCRIPT);
			adURLBuilder.append(newOpenXParameters);
			String adURLString = adURLBuilder.toString();			
			try {		
				CookieManager mJAXcookiemanager = new CookieManager();
				CookieHandler.setDefault(mJAXcookiemanager);				
				final URL adURL = new URL(adURLString);				
				URLConnection conn = adURL.openConnection();
				SharedPreferences  mJAXspload = PreferenceManager.getDefaultSharedPreferences(getContext());
	            String cookienameandvalue = mJAXspload.getString("OAID", null);	
				System.out.println("OAID="+cookienameandvalue);	
                conn.setRequestProperty("Cookie", "OAID="+cookienameandvalue);         
	            conn.setDoOutput(true);
	            conn.setDoInput(true);
				conn.connect();				
				InputStream is = conn.getInputStream();
				Object obj1 = conn.getContent();						
				CookieStore mJAXcookie = mJAXcookiemanager.getCookieStore();
				List<HttpCookie> cookies = mJAXcookie.getCookies();
				for (HttpCookie cookie : cookies) {					
					editor.putString(cookie.getName(), cookie.getValue());    
					 editor.commit();										 		 
				}				
				try {
					final Bitmap bm = BitmapFactory.decodeStream(is);					
					handler.post(new MyAdDisplayer(newOpenXParameters, bm));					
				} finally {
					is.close();
				}
			} catch(Exception ex) {
				Log.e(MjaXAdmanager.LOG_PREFIX, "Problem fetching ad image from "+adURLString, ex);
			}		
		}		
	}	
	private class MyAdDisplayer implements Runnable {
		private final transient String newOpenXParameters;
		private final transient Bitmap adImage;
		public MyAdDisplayer(final String newOpenXParameters, final Bitmap adImage) {
			this.newOpenXParameters = newOpenXParameters;
			this.adImage = adImage;
		}
			public void run() {
			MjaXAdmanager.this.setImageBitmap(adImage);
			MjaXAdmanager.this.openXParameters = newOpenXParameters;
		}
	}
}
