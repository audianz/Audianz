package com.example.mjax;

import com.example.mjax.adsdk.MjaXAdmanager;

import android.os.Bundle;
import android.app.Activity;
public class MjaxActivity extends Activity {
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.mjaxlayout);
	        MjaXAdmanager widget = (MjaXAdmanager)findViewById(R.id.mjaxlayoutid);
	        widget.setServer("50.23.160.154/~djax/mjaxadnetwork_demo/ads/www/delivery/");//Get From Dashboard
	        widget.setZoneId(1); //Get from Dashboard
	    }
	}
