#import <UIKit/UIKit.h>

@interface classprefixViewController : UIViewController{    
    IBOutlet   UIImageView *urlImage;
   
}

- (IBAction)urlClick:(id)sender;

@end






