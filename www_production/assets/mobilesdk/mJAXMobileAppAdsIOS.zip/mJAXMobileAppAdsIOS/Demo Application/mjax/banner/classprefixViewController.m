#import "classprefixViewController.h"
@implementation classprefixViewController
- (void)viewDidLoad
{     
    [super viewDidLoad];    
    [self adRequest];

}
- (void)adRequest
{
    for (NSHTTPCookie *cookie in [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies]) {
        if ([cookie.name rangeOfString:@"OAVARS[default]"].location == NSNotFound) {
        } else {
            [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
        }
    }    
 NSURL *url = [NSURL URLWithString:@"http://50.23.160.154/~djax/mjaxadnetwork_demo/ads/www/delivery/avw.php?zoneid=1"];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    NSHTTPURLResponse *response;
    [NSURLConnection  sendSynchronousRequest:request  returningResponse: &response error: nil];
    NSURL *adLocation=[response URL];
    [NSHTTPCookie cookiesWithResponseHeaderFields:[response allHeaderFields] forURL:url];
    //Ad View
   urlImage.image=[UIImage imageWithData:[NSData dataWithContentsOfURL:adLocation]];
    //Ad Refresh    
    [NSTimer scheduledTimerWithTimeInterval:90.0 target:self selector:@selector(adRequest) userInfo:nil  repeats:NO];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


- (IBAction)urlClick:(id)sender
{
    
    //Ad Click
    [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];    
    for (NSHTTPCookie *cookie in [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies])
    {        
        if ([cookie.name rangeOfString:@"OAVARS[default]"].location == NSNotFound) {           
        } else {
            NSUInteger count = 0, startpos=0, endpos=0, length = [cookie.value length];
            NSRange range = NSMakeRange(0, length);            
             while(range.location != NSNotFound)
             {
             range = [cookie.value rangeOfString: @"%22" options:0 range:range];
             if(range.location != NSNotFound)
             {
             range = NSMakeRange(range.location + range.length, length - (range.location + range.length)); 
             count++;                         
             if(count==3)
             {
             startpos=range.location;
             }
             if(count==4)
             {
              endpos=(range.location-3)-startpos;
              }
             }
            }                    
            NSRange r = NSMakeRange(startpos,endpos);           
            NSString *bannerid=[cookie.value substringWithRange:r];
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://50.23.160.154/~djax/mjaxadnetwork_demo/ads/www/delivery/ck.php?zoneid=1&bannerid=%@",bannerid]]];
            break;
        }        
        }
    
    
    
}
@end

