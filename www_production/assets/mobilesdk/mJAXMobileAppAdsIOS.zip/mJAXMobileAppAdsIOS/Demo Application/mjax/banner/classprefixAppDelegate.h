#import <UIKit/UIKit.h>

@class classprefixViewController;

@interface classprefixAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) classprefixViewController *viewController;

@end
