//
//  main.m
//  banner
//
//  Created by Dreamajax on 07/01/13.
//  Copyright (c) 2013 orgname. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "classprefixAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([classprefixAppDelegate class]));
    }
}
